#include <stdio.h>

int main(void)
{
    int i = 1;
    while (i <= 10)
    {
        printf("Hello World %d\n", i++);
        //i++;
    }

    return 0;
}
