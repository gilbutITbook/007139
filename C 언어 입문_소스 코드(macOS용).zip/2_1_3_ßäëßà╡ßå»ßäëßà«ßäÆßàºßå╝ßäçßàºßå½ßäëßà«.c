#include <stdio.h>

int main(void)
{
    float f = 46.5f;
    printf("%.2f\n", f);
    double d = 4.428;
    printf("%.2lf\n", d);
    return 0;
}
