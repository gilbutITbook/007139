#include <stdio.h>

int main(void)
{
    const int YEAR = 2000;
    printf("태어난 년도 : %d\n", YEAR);
    //YEAR = 2001;
    return 0;
}
