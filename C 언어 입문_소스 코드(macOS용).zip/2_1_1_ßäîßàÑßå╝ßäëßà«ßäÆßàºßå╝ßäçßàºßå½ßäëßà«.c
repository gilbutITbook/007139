#include <stdio.h>

int main(void)
{
    int age = 12;
    printf("%d\n", age);
    age = 13;
    printf("%d\n", age);
    return 0;
}
