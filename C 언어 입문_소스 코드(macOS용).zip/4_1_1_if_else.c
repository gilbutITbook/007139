#include <stdio.h>

int main(void)
{
    int age = 25;
    if (age >= 20)
    {
        printf("일반인 입니다\n");
    }
    else
    {
        printf("학생입니다\n");
    }

    return 0;
}
