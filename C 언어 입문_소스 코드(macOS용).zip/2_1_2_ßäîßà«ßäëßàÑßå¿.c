#include <stdio.h>

int main(void)
{
    /*int age = 12;
    printf("%d\n", age);
    age = 13;
    printf("%d\n", age);*/

    printf("1\n");
    //printf("2\n");
    printf("3\n");

    return 0;
}
