#include <stdio.h>

int main(void)
{
    int arr[10] = { 1, 2 }; // 일부 값 초기화
    for (int i = 0; i < 10; i++)
    {
        printf("%d\n", arr[i]);
    }
    return 0;
}
