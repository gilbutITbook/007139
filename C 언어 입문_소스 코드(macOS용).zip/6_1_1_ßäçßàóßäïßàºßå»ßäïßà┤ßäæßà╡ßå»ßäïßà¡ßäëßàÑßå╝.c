#include <stdio.h>

int main(void)
{
    int subway_1 = 30;
    int subway_2 = 40;
    int subway_3 = 50;
    
    printf("지하철 1호차에 %d 명이 타고 있습니다\n", subway_1);
    printf("지하철 2호차에 %d 명이 타고 있습니다\n", subway_2);
    printf("지하철 3호차에 %d 명이 타고 있습니다\n", subway_3);

    return 0;
}
